package hospitalmanagement;

import javax.swing.JOptionPane;

public class Person {
    protected String firstName;
    protected String lastName;
    protected String streetAddress;
    protected String zipCode;
    protected String phoneNumber;

    public void setPersonDetails() {
        firstName = JOptionPane.showInputDialog("Enter First Name:");
        lastName = JOptionPane.showInputDialog("Enter Last Name:");
        streetAddress = JOptionPane.showInputDialog("Enter Street Address:");
        zipCode = JOptionPane.showInputDialog("Enter Zip Code:");
        phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");
    }

    public void displayDetails() {
        System.out.println(firstName + " " + lastName + ", " + streetAddress + ", " + zipCode + ", " + phoneNumber);
    }
}

//Title: Hospital Management System Project in Java
//Author: Copy Assignment
//Date:16 September 2024
//Version: 1
//Available:https://copyassignment.com/hospital-management-system-project-in-java/
