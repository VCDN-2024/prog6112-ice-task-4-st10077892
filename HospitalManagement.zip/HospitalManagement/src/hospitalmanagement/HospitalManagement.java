package hospitalmanagement;

import javax.swing.JOptionPane;

public class HospitalManagement {
    public static void main(String[] args) {
        HospitalStaff[] hospitalStaff = new HospitalStaff[4];
        Doctor[] doctors = new Doctor[3];
        Patient[] patients = new Patient[7];
        
        int staffCount = 0, doctorCount = 0, patientCount = 0;

        while (true) {
            String option = JOptionPane.showInputDialog("Enter H for Hospital Staff, D for Doctor, P for Patient, or Q to quit:");
            if (option.equalsIgnoreCase("Q")) {
                break;
            }

            switch (option.toUpperCase()) {
                case "H":
                    if (staffCount < 4) {
                        hospitalStaff[staffCount] = new HospitalStaff();
                        hospitalStaff[staffCount].setPersonDetails();
                        staffCount++;
                    } else {
                        System.out.println("Error: Maximum Hospital Staff reached.");
                    }
                    break;
                case "D":
                    if (doctorCount < 3) {
                        doctors[doctorCount] = new Doctor();
                        doctors[doctorCount].setPersonDetails();
                        doctorCount++;
                    } else {
                        System.out.println("Error: Maximum Doctors reached.");
                    }
                    break;
                case "P":
                    if (patientCount < 7) {
                        patients[patientCount] = new Patient();
                        patients[patientCount].setPersonDetails();
                        patientCount++;
                    } else {
                        System.out.println("Error: Maximum Patients reached.");
                    }
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        }

        // Display the report
        System.out.println("\nHospital Staff:");
        if (staffCount == 0) {
            System.out.println("No Hospital Staff entered.");
        } else {
            for (int i = 0; i < staffCount; i++) {
                hospitalStaff[i].displayDetails();
            }
        }

        System.out.println("\nDoctors:");
        if (doctorCount == 0) {
            System.out.println("No Doctors entered.");
        } else {
            for (int i = 0; i < doctorCount; i++) {
                doctors[i].displayDetails();
            }
        }

        System.out.println("\nPatients:");
        if (patientCount == 0) {
            System.out.println("No Patients entered.");
        } else {
            for (int i = 0; i < patientCount; i++) {
                patients[i].displayDetails();
            }
        }
    }
}

//Title: Hospital Management System Project in Java
//Author: Copy Assignment
//Date:16 September 2024
//Version: 1
//Available:https://copyassignment.com/hospital-management-system-project-in-java/
