package hospitalmanagement;

import javax.swing.JOptionPane;

public class Doctor extends HospitalStaff {
    private boolean isSpecialist;

    @Override
    public void setPersonDetails() {
        super.setPersonDetails();
        isSpecialist = JOptionPane.showConfirmDialog(null, "Is the Doctor a Specialist?") == JOptionPane.YES_OPTION;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Specialist: " + (isSpecialist ? "Yes" : "No"));
    }
}

//Title: Hospital Management System Project in Java
//Author: Copy Assignment
//Date:16 September 2024
//Version: 1
//Available:https://copyassignment.com/hospital-management-system-project-in-java/

