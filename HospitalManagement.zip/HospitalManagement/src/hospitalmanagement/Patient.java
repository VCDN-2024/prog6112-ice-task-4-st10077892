package hospitalmanagement;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Patient extends Person {
    private String medicalRecordNumber;
    private ArrayList<String> ailments;

    @Override
    public void setPersonDetails() {
        super.setPersonDetails();
        medicalRecordNumber = JOptionPane.showInputDialog("Enter Medical Record Number:");
        ailments = new ArrayList<>();
        while (true) {
            String ailment = JOptionPane.showInputDialog("Enter an ailment (or 'Q' to stop):");
            if (ailment.equalsIgnoreCase("Q")) {
                break;
            }
            ailments.add(ailment);
        }
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Medical Record Number: " + medicalRecordNumber);
        System.out.println("Ailments: " + String.join(", ", ailments));
    }
}

//Title: Hospital Management System Project in Java
//Author: Copy Assignment
//Date:16 September 2024
//Version: 1
//Available:https://copyassignment.com/hospital-management-system-project-in-java/
