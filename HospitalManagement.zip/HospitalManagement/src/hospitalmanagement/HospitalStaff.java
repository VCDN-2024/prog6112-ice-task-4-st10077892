package hospitalmanagement;

import javax.swing.JOptionPane;

public class HospitalStaff extends Person {
    protected String staffID;
    protected double annualSalary;
    protected String department;

    @Override
    public void setPersonDetails() {
        super.setPersonDetails();
        staffID = JOptionPane.showInputDialog("Enter Staff ID:");
        annualSalary = Double.parseDouble(JOptionPane.showInputDialog("Enter Annual Salary:"));
        department = JOptionPane.showInputDialog("Enter Department Name:");
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Staff ID: " + staffID + ", Annual Salary: " + annualSalary + ", Department: " + department);
    }
}

//Title: Hospital Management System Project in Java
//Author: Copy Assignment
//Date:16 September 2024
//Version: 1
//Available:https://copyassignment.com/hospital-management-system-project-in-java/

